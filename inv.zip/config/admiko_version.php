<?php
/** Admiko version file **/
/**
 * @author     Thank you for using Admiko.com
 * @copyright  2020-2022
 * @link       https://Admiko.com
 * @Help       We are always looking to improve our code. If you know better and more creative way don't hesitate to contact us. Thank you.
 */
/**
 * This file will be overwritten on update. Don't add your code here!
 */
return [
    'project_key'             => '596953b3bd9495bebe73a26705f26e9ebf7d332a4716b174b2',
    'version'             => 0.918
];
