<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route("admin.users.index")); ?>">Users</a></li>
    <?php $__currentLoopData = App\Models\Admin\Users::buildParentChildrenBreadcrumbs(Request()->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item active" aria-current="page">
                <a href="<?php echo e(route("admin.users.index",$id)); ?>"><?php echo e($title); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(isset($data)): ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_edit')); ?></li>
    <?php else: ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_add')); ?></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
<h1>Users</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
<a href="<?php echo e(route("admin.users.index",$data->admiko_parent_child??Request()->id)); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card formPage users_manage admikoForm">
    <legend class="action"><?php echo e(isset($data) ? trans('admiko.update') : trans('admiko.add_new')); ?></legend>
    <form method="POST" action="<?php echo e($admiko_data['formAction']); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php if(isset($data)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if($errors->any()): ?><div class="row"><div class="col-2"></div><div class="col"><div class="invalid-feedback d-block"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($error); ?><br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div></div><?php endif; ?>
            <div class="row">
                
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="name" class="col-md-2 col-form-label">Name:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="name" name="name"  placeholder="Name"  value="<?php echo e(old('name', isset($data)?$data->name : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('name')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="name_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="mobile" class="col-md-2 col-form-label">Mobile:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="mobile" name="mobile"  placeholder="Mobile"  value="<?php echo e(old('mobile', isset($data)?$data->mobile : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('mobile')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="mobile_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="city" class="col-md-2 col-form-label">City:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="city" name="city"  placeholder="City"  value="<?php echo e(old('city', isset($data)?$data->city : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('city')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="city_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="admiko_parent_child" class="col-md-2 col-form-label">Higher Authority:</label>
                        <div class="col-md-10">
                            <select class="form-select" id="admiko_parent_child" name="admiko_parent_child">
                                <option value="0"><?php echo e(trans('admiko.parent_title')); ?></option>
                                <?php $__currentLoopData = $data_admiko_parent_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php if(isset($data) && $id == Request()->id): ?>disabled="disabled"<?php endif; ?> <?php echo e((old('admiko_parent_child') ? old('admiko_parent_child') : $data->admiko_parent_child ?? (Request()->id??0)) == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback <?php if($errors->has('admiko_parent_child')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="admiko_parent_child_help" class="text-muted"></small>
                            <input type="hidden" name="return_page" value="<?php echo e($data->admiko_parent_child??(Request()->id??'')); ?>">
                            <input type="hidden" name="admiko_parent_id" value="<?php echo e($data->admiko_parent_child??''); ?>">
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="basic_amount" class="col-md-2 col-form-label">Basic Amount:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="basic_amount" name="basic_amount"  placeholder="Basic Amount"  value="<?php echo e(old('basic_amount', isset($data)?$data->basic_amount : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('basic_amount')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="basic_amount_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="user_type" class="col-md-2 col-form-label">User Type:*</label>
                        <div class="col-md-10">
                            <select class="form-select" id="user_type" name="user_type" required="true">
                                
                                <?php $__currentLoopData = $user_type_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((old('user_type') ? old('user_type') : $data->user_type ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback <?php if($errors->has('user_type')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="user_type_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="card-footer form-actions" id="form-group-buttons">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary float-start me-1 mb-1 mb-sm-0 save-button"><?php echo e(trans('admiko.table_save')); ?></button>
                    <a href="<?php echo e(route("admin.users.index",$data->admiko_parent_child??Request()->id)); ?>" class="btn btn-secondary float-end" role="button"><?php echo e(trans('admiko.table_cancel')); ?></a>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/users/manage.blade.php ENDPATH**/ ?>