<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active"><a href="<?php echo e(route("admin.customer.index")); ?>">Customer</a></li>
    <?php if(isset($data)): ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_edit')); ?></li>
    <?php else: ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_add')); ?></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
<h1>Customer</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
<a href="<?php echo e(route("admin.customer.index")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card formPage customer_manage admikoForm">
    <legend class="action"><?php echo e(isset($data) ? trans('admiko.update') : trans('admiko.add_new')); ?></legend>
    <form method="POST" action="<?php echo e($admiko_data['formAction']); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php if(isset($data)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if($errors->any()): ?><div class="row"><div class="col-2"></div><div class="col"><div class="invalid-feedback d-block"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($error); ?><br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div></div><?php endif; ?>
            <div class="row">
                
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="name" class="col-md-2 col-form-label">Name:*</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="name" name="name" required="true" placeholder="Name"  value="<?php echo e(old('name', isset($data)?$data->name : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('name')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="name_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="address" class="col-md-2 col-form-label">Address:*</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="address" name="address" required="true" placeholder="Address"  value="<?php echo e(old('address', isset($data)?$data->address : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('address')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="address_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="adhar_number" class="col-md-2 col-form-label">Adhar Number:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="adhar_number" name="adhar_number"  placeholder="Adhar Number"  value="<?php echo e(old('adhar_number', isset($data)?$data->adhar_number : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('adhar_number')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="adhar_number_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="adhar_front_image" class="col-md-2 col-form-label">Adhar Front Image:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->adhar_front_image) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["adhar_front_image"]['original']["folder"].$data->adhar_front_image)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["adhar_front_image"]['original']["folder"].$data->adhar_front_image)); ?>" target="_blank" class="tableImage">
                                    <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["adhar_front_image"]['original']["folder"].$data->adhar_front_image)); ?>">
                                </a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="adhar_front_image_admiko_delete" id="adhar_front_image_admiko_delete" value="1">
                                <label class="form-check-label" for="adhar_front_image_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="imageUpload mt-1" id="adhar_front_image" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg"  name="adhar_front_image"  data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>" >
                            <input type="hidden" id="adhar_front_image_admiko_current" name="adhar_front_image_admiko_current" value="<?php echo e($data->adhar_front_image??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('adhar_front_image')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('adhar_front_image')): ?><?php echo e($errors->first('adhar_front_image')); ?><?php endif; ?>
                            </div>
                            <small id="adhar_front_image_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>1920px, <?php echo e(trans("admiko.height")); ?>1080px. <?php echo e(trans("admiko.image_action")); ?><?php echo e(trans("admiko.image_action_resize")); ?>.</small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="adhar_back_image" class="col-md-2 col-form-label">Adhar Back Image:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->adhar_back_image) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["adhar_back_image"]['original']["folder"].$data->adhar_back_image)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["adhar_back_image"]['original']["folder"].$data->adhar_back_image)); ?>" target="_blank" class="tableImage">
                                    <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["adhar_back_image"]['original']["folder"].$data->adhar_back_image)); ?>">
                                </a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="adhar_back_image_admiko_delete" id="adhar_back_image_admiko_delete" value="1">
                                <label class="form-check-label" for="adhar_back_image_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="imageUpload mt-1" id="adhar_back_image" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg"  name="adhar_back_image"  data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>" >
                            <input type="hidden" id="adhar_back_image_admiko_current" name="adhar_back_image_admiko_current" value="<?php echo e($data->adhar_back_image??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('adhar_back_image')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('adhar_back_image')): ?><?php echo e($errors->first('adhar_back_image')); ?><?php endif; ?>
                            </div>
                            <small id="adhar_back_image_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>1920px, <?php echo e(trans("admiko.height")); ?>1080px. <?php echo e(trans("admiko.image_action")); ?><?php echo e(trans("admiko.image_action_resize")); ?>.</small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="mobile" class="col-md-2 col-form-label">Mobile:*</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="mobile" name="mobile" required="true" placeholder="Mobile"  value="<?php echo e(old('mobile', isset($data)?$data->mobile : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('mobile')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="mobile_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer form-actions" id="form-group-buttons">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary float-start me-1 mb-1 mb-sm-0 save-button"><?php echo e(trans('admiko.table_save')); ?></button>
                    <a href="<?php echo e(route("admin.customer.index")); ?>" class="btn btn-secondary float-end" role="button"><?php echo e(trans('admiko.table_cancel')); ?></a>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/customer/manage.blade.php ENDPATH**/ ?>