<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div  class="content-wrapper">
        <div>
            <div class="panel panel-default">
                <div class="panel-heading role-list-info-header">
                  <a href="<?php echo e(url('/simtypes')); ?>" class="btn btn-success">Add New Sim</a>
                    <p>SIM Table</p>
                    
                </div>

                <!-- /.panel-heading -->
                <div class="panel-body">




<table class="table table-striped table-dark">
  <thead>
    <tr>
      
      <th scope="col"><table class="table table-striped table-dark">
  <thead>
    <tr>
    <th scope="col">id</th>
      <th scope="col">name</th>

    </tr>


  </thead>
  <?php  $data=DB::table('sim_types')->get();?>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->name); ?></td>
                
              
                
                 <td>
                  <a href="<?php echo e(url('/')); ?>/sim_edit?id=<?php echo e($row->id); ?>" class="btn btn-primary">Edit</a>
                </td>
                <td>
                <a href="<?php echo e(url('/')); ?>/sim_destroy?id=<?php echo e($row->id); ?>" class="btn btn-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    </div>

    <?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/sim_table.blade.php ENDPATH**/ ?>