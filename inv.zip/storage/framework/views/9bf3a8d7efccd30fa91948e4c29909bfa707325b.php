<?php $__env->startSection('breadcrumbs'); ?>
<li class="breadcrumb-item active" aria-current="page">Vechicles</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
<h1>Vechicles</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
<a href="<?php echo e(route("admin.home")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card vechicles_index admikoIndex">
    <div class="card-body">
        <div class="tableBox" id="tableBox">
            <div class="row">
                <div class="col-12 d-flex justify-content-between">
                    <div class="pb-2 pb-sm-0">
                        <div class="lengthTable"></div>
                    </div>
                    <div>
                        <div class="d-flex justify-content-start justify-content-sm-end">
                            <div class="searchTable">
					<div class="input-group ps-2">
                        <input type="text" name="admiko_search" class="form-control searchTableInput" placeholder="Search" value="">
                    </div></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tableLayout pb-2">
                                <table class="table tableSort" style="width:100%" data-dom="ltrip">
                    <thead>
                        <tr data-sort-method='thead'>
							<th scope="col" class="w-5" data-sort-method="number" >ID</th>
							<th scope="col" class="text-nowrap">Vechicle Number</th>
							<th scope="col" class="text-nowrap d-none d-sm-table-cell">Customer</th>
							<th scope="col" class="d-none d-md-table-cell">RC Book File</th>
							<th scope="col" class="d-none d-lg-table-cell">Vehicle Image 1</th>
                            <th scope="col" class="w-5 no-sort" data-orderable="false"><?php echo e(trans("admiko.table_edit")); ?></th>
                            <?php if(Gate::allows('vechicles_allow')): ?>
                            <th scope="col" class="w-5 no-sort" data-orderable="false"><?php echo e(trans('admiko.table_delete')); ?></th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $tableData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
							<td class="w-5"><a href="<?php echo e(route("admin.vechicles.edit",[$data->id])); ?>"><?php echo e($data->id); ?></a></td>
							<td class="text-nowrap"><?php echo e($data->vechicle_number); ?></td>
							<td class="text-nowrap d-none d-sm-table-cell"><?php echo e($data->customer_id->name??""); ?></td>
							<td class="d-none d-md-table-cell"><?php echo e($data->rc_book_file); ?></td>
							<td class="d-none d-lg-table-cell"><?php if(isset($data->vehicle_image_1) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data["fileInfo"]["vehicle_image_1"]["original"]["folder"].$data->vehicle_image_1)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data["fileInfo"]["vehicle_image_1"]["original"]["folder"].$data->vehicle_image_1)); ?>" target="_blank" class="tableImage">
                                <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data["fileInfo"]["vehicle_image_1"]["original"]["folder"].$data->vehicle_image_1)); ?>">
                            </a><?php endif; ?></td>
                            <td class="w-5 no-sort"><a href="<?php echo e(route("admin.vechicles.edit",[$data->id])); ?>"><i class="fas fa-edit fa-fw"></i></a></td>
                            <?php if(Gate::allows(['vechicles_allow'])): ?>
                            <td class="w-5 no-sort">
                            <a href="#" data-id="<?php echo e($data->id); ?>" class="admiko_deleteConfirm" data-bs-toggle="modal" data-bs-target="#deleteConfirm"><i class="fas fa-trash fa-fw"></i></a>
                        </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col-12 col-sm order-3 order-sm-0 pt-2">
                    <?php if(Gate::any(['vechicles_allow'])): ?>
                        <a href="<?php echo e(route('admin.vechicles.create')); ?>" class="btn btn-primary" role="button"><i class="fas fa-plus fa-fw"></i> <?php echo e(trans('admiko.table_add')); ?></a>
                    <?php endif; ?>
                </div>
                <div class="col-12 col-sm-auto order-0 order-sm-3 pt-2 align-self-center paginationInfo"></div>
                <div class="col-12 col-sm-auto order-0 order-sm-3 pt-2 text-end paginationBox"></div>
            </div>
        </div>
    </div>
    <?php if(Gate::allows('vechicles_allow')): ?>
    <!-- Delete confirm -->
    <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirm" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="post" class="w-100" action="<?php echo e(route("admin.vechicles.delete")); ?>">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(trans('admiko.delete_confirm')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body"><?php echo e(trans('admiko.delete_message')); ?></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(trans('admiko.delete_close_btn')); ?></button>
                    <button type="submit" class="btn btn-danger deleteSoft"><?php echo e(trans('admiko.delete_delete_btn')); ?></button>
                </div>
            </div>
            <div class="dataDelete"></div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/vechicles/index.blade.php ENDPATH**/ ?>