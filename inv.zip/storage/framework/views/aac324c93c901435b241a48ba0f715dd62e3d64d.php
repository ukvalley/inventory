<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active"><?php echo e(trans('admiko.myaccount')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
    <h1><?php echo e(trans('admiko.myaccount')); ?></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
    <a href="<?php echo e(route("admin.home")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card formPage">
        <legend class="action"><?php echo e(trans('admiko.update')); ?></legend>
        <form method="POST" action="<?php echo e(route('admin.myaccount.update')); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group row">
                    <label for="name" class="col-sm-2 col-form-label"><?php echo e(trans('admiko.admins_name')); ?>:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo e(trans('admiko.admins_name')); ?>" value="<?php echo e(old('name', isset($data)?$data->name : '')); ?>">
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback d-block"><?php echo e($errors->first('name')); ?></div><?php endif; ?>
                        <div class="invalid-feedback"><?php echo e(trans('admiko.required_text')); ?></div>
                        <small id="name_help" class="form-text text-muted"></small>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="email" class="col-sm-2 col-form-label"><?php echo e(trans('admiko.admins_email')); ?>:</label>
                    <div class="col-sm-10">
                        <input type="email" class="form-control" id="email" name="email" placeholder="<?php echo e(trans('admiko.admins_email')); ?>" value="<?php echo e(old('email', $data->email??'')); ?>">
                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback d-block"><?php echo e($errors->first('email')); ?></div><?php endif; ?>
                        <div class="invalid-feedback"><?php echo e(trans('admiko.required_text')); ?></div>
                        <small id="email_help" class="form-text text-muted"></small>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="image" class="col-sm-2 col-form-label">Image:</label>
                    <div class="col-sm-10">
                        <?php if(isset($data->image)): ?>
                            <img class="stored_image" src="<?php echo e($data->image); ?>"><br>
                        <?php endif; ?>
                        <input type="hidden" name="image" id="imageData" value="<?php echo e($data->image); ?>">
                        <input type="file" class="imageAvatarUpload mt-1" id="image" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg" data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>">
                        <div class="invalid-feedback" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>"></div>
                        <small id="image_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>200px, <?php echo e(trans("admiko.height")); ?>200px.</small>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="themes" class="col-sm-2 col-form-label">Themes:</label>
                    <div class="col-sm-10">
                        <div class="row">
                            <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $checked = ""; ?>
                                <?php if(old('theme') == $theme): ?>
                                    <?php $checked = "checked"; ?>
                                <?php elseif(isset($data) && $data->theme == $theme): ?>
                                    <?php $checked = "checked"; ?>
                                <?php endif; ?>
                                <div class="col-4 themeSelect mb-3">
                                    <label class="form-check-label" for="theme<?php echo e($theme); ?>" style="text-transform: capitalize">
                                        <img src="/assets/admiko/css/theme/<?php echo e($theme); ?>/image.jpg" class="img-thumbnail">
                                        <input type="radio" class="form-check-input" name="theme" id="theme<?php echo e($theme); ?>" value="<?php echo e($theme); ?>" <?php echo e($checked); ?> > <?php echo e($theme); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="form-actions">
                    <div class="row" id="form-group-buttons">
                        <div class="col-2"></div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary mb-5 mb-sm-0 ms-3 ms-sm-0 save-button"><?php echo e(trans('admiko.table_save')); ?></button>
                        </div>
                        <div class="secondaryButtons col pt-0 text-end">
                            <a href="<?php echo e(route("admin.home")); ?>" class="btn btn-secondary mb-1 mb-sm-0  ms-3 ms-sm-0" role="button"><?php echo e(trans('admiko.table_cancel')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <legend class="action"><?php echo e(trans('admiko.new_password')); ?></legend>
        <form method="POST" action="<?php echo e(route('admin.myaccount.updatepassword')); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group row">
                    <label for="password" class="col-sm-2 col-form-label"><?php echo e(trans('admiko.admins_pass')); ?>:</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" id="password" name="password" placeholder="<?php echo e(trans('admiko.admins_pass')); ?>" value="<?php echo e(old('password'??'')); ?>">
                        <?php if($errors->has('password')): ?>
                            <div class="invalid-feedback d-block"><?php echo e($errors->first('password')); ?></div><?php endif; ?>
                        <div class="invalid-feedback"><?php echo e(trans('admiko.required_text')); ?></div>
                        <small id="password_help" class="form-text text-muted"></small>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="form-actions">
                    <div class="row" id="form-group-buttons">
                        <div class="col-2"></div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary mb-5 mb-sm-0 ms-3 ms-sm-0 save-button"><?php echo e(trans('admiko.table_save')); ?></button>
                        </div>
                        <div class="secondaryButtons col pt-0 text-end">
                            <a href="<?php echo e(route("admin.home")); ?>" class="btn btn-secondary mb-1 mb-sm-0  ms-3 ms-sm-0" role="button"><?php echo e(trans('admiko.table_cancel')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/admins/myaccount.blade.php ENDPATH**/ ?>