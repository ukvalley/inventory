<?php $__env->startSection('breadcrumbs'); ?>
<li class="breadcrumb-item active" aria-current="page">Sales</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
<h1>Sales</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
<a href="<?php echo e(route("admin.home")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card sales_index admikoIndex">
    <div class="card-body">
        <div class="tableBox" id="tableBox">
            <div class="row">
                <div class="col-12 d-flex justify-content-between">
                    <div class="pb-2 pb-sm-0">
                        <div class="lengthTable"></div>
                    </div>
                    <div>
                        <div class="d-flex justify-content-start justify-content-sm-end">
                            <div class="searchTable">
					<div class="input-group ps-2">
                        <input type="text" name="admiko_search" class="form-control searchTableInput" placeholder="Search" value="">
                    </div></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tableLayout pb-2">
                                <table class="table tableSort" style="width:100%" data-dom="ltrip">
                    <thead>
                        <tr data-sort-method='thead'>
							<th scope="col" class="w-5" data-sort-method="number" >ID</th>
                            <th scope="col" class="w-5 no-sort" data-orderable="false"><?php echo e(trans("admiko.table_edit")); ?></th>
                            <?php if(Gate::allows('sales_allow')): ?>
                            <th scope="col" class="w-5 no-sort" data-orderable="false"><?php echo e(trans('admiko.table_delete')); ?></th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $tableData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
							<td class="w-5"><a href="<?php echo e(route("admin.sales.edit",[$data->id])); ?>"><?php echo e($data->id); ?></a></td>
                            <td class="w-5 no-sort"><a href="<?php echo e(route("admin.sales.edit",[$data->id])); ?>"><i class="fas fa-edit fa-fw"></i></a></td>
                            <?php if(Gate::allows(['sales_allow'])): ?>
                            <td class="w-5 no-sort">
                            <a href="#" data-id="<?php echo e($data->id); ?>" class="admiko_deleteConfirm" data-bs-toggle="modal" data-bs-target="#deleteConfirm"><i class="fas fa-trash fa-fw"></i></a>
                        </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col-12 col-sm order-3 order-sm-0 pt-2">
                    <?php if(Gate::any(['sales_allow'])): ?>
                        <a href="<?php echo e(route('admin.sales.create')); ?>" class="btn btn-primary" role="button"><i class="fas fa-plus fa-fw"></i> <?php echo e(trans('admiko.table_add')); ?></a>
                    <?php endif; ?>
                </div>
                <div class="col-12 col-sm-auto order-0 order-sm-3 pt-2 align-self-center paginationInfo"></div>
                <div class="col-12 col-sm-auto order-0 order-sm-3 pt-2 text-end paginationBox"></div>
            </div>
        </div>
    </div>
    <?php if(Gate::allows('sales_allow')): ?>
    <!-- Delete confirm -->
    <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirm" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="post" class="w-100" action="<?php echo e(route("admin.sales.delete")); ?>">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(trans('admiko.delete_confirm')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body"><?php echo e(trans('admiko.delete_message')); ?></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(trans('admiko.delete_close_btn')); ?></button>
                    <button type="submit" class="btn btn-danger deleteSoft"><?php echo e(trans('admiko.delete_delete_btn')); ?></button>
                </div>
            </div>
            <div class="dataDelete"></div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/sales/index.blade.php ENDPATH**/ ?>