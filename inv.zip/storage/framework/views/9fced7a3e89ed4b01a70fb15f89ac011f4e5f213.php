<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 <!-- Main content -->
 <div class="content-wrapper">
 <section class="content">
               <div class="row">
                  <!-- Form controls -->
                  <div class="col-sm-12">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="btn-group" id="buttonlist"> 
                              <a class="btn btn-add " href="clist.html"> 
                              <i class="fa fa-list"></i> User Registration </a>  
                           </div>
                        </div>
                        <div class="panel-body">
                           <form class="col-sm-6" action="<?php echo e(url('/')); ?>/register_user-update/<?php echo e($data->id); ?>" method="post"  enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                 
                                
                           <div class="form-group">
                                 <label>Name</label>
                                 <input type="text" class="form-control" name="name" value="<?php echo e($data->name); ?>" placeholder="Name" required>
                              </div>

                              <div class="form-group">
                                 <label>Mobile</label>
                                 <input type="number" class="form-control" name="mobile" value="<?php echo e($data->mobile); ?>" placeholder="Enter Mobile" required>
                              </div>

                               <div class="form-group">
                                 <label>City</label>
                                 <input type="text" class="form-control" name="city" value="<?php echo e($data->city); ?>" placeholder=" City" required>
                              </div>
                              


                              <div class="form-group">
                                 <label>Higher Authority</label>
                                 <select class="form-control" name="admiko_parent_child" id="admiko_parent_child">
                                    <option value="0" <?php if($data->admiko_parent_child == '0'): ?> selected="true" <?php endif; ?> >Parent</option>
                                    <?php $__currentLoopData = $allusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" <?php if($data->admiko_parent_child == $value->id): ?> selected="true" <?php endif; ?> ><?php echo e($value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                           
                   
                                 </select>
                              </div>

                              <div class="form-group">
                              <label>Bacic Amount</label>
                                 <input type="text" class="form-control" name="basic_amount" value="<?php echo e($data->basic_amount); ?>" placeholder=" >Bacic Amount" required>
                              </div>
                               <div class="form-group">
                                 <label>User Type</label>
                                 <select class="form-control"  name="user_type"  id="user_type">
                                    <option>Sales Agent</option>
                                    <option>Technician</option>
                                    <option>Admin</option>
                                 </select>
                              </div>

                              

                              
                             

                              <div class="reset-button">
                                 <a href="#" class="btn btn-warning">Reset</a>
                                 <input class="btn btn-success" type="submit" value="Submit" />
                              </div>
                           
                           
                             
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-- /.content -->
            </div>

<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views//user_edit.blade.php ENDPATH**/ ?>