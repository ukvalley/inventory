<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->make('admin.layouts.header_custom_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.layouts.header_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.layouts.header_custom_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admiko</title>
</head>
<body>
<div class="containerBox">
    <header>
        <nav class="navbar">
            <div class="navbar-header d-flex justify-content-center align-items-center">
                <a class="navbar-brand" href="<?php echo e(route("admin.home")); ?>">
                    <img src="<?php echo e(asset('assets/admiko/images/logo.png')); ?>">
                </a>
            </div>
            <div class="sidebar">
                <div class="sidebar-user">
                    <a href="<?php echo e(route("admin.myaccount")); ?>">
                        <img src="<?php echo e(auth()->user()->image); ?>" class="img-fluid">
                    </a>
                    <div class="sidebar-user-name"><?php echo e(auth()->user()->name); ?></div>
                    <div class="sidebar-user-email"><?php echo e(auth()->user()->email); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <div class="menu-title">
                            <div>Menu</div>
                        </div>
                    </li>
                    <li class="nav-item page<?php echo e($admiko_data['sideBarActive'] === "home" ? " active" : ""); ?>">
                        <a class="nav-link" href="<?php echo e(route("admin.home")); ?>"><i class="fas fa-home fa-fw"></i><?php echo e(trans('admiko.home')); ?></a>
                    </li>
                    <?php echo $__env->make('admin.custom_sidebar_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <?php echo $__env->make('admin.admiko_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <?php echo $__env->make('admin.custom_sidebar_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <li class="nav-item myaccount<?php echo e($admiko_data['sideBarActive'] === "myaccount" ? " active" : ""); ?>">
                        <a class="nav-link" href="<?php echo e(route("admin.myaccount")); ?>"><i class="fas fa-user fa-fw"></i><?php echo e(trans('admiko.myaccount')); ?></a>
                    </li>
                    <li class="nav-item logout">
                        <a class="nav-link" href="<?php echo e(route("admin.logout")); ?>"><i class="fas fa-power-off fa-fw"></i><?php echo e(trans('admiko.logout')); ?></a>
                    </li>
                    <?php echo $__env->make('admin.layouts.admiko_developer_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
            </div>
        </nav>
        <footer>
            <a href="https://admiko.com" target="_blank">&copy; <?php echo e(date("Y")); ?> Powered by ADMIKO</a>
        </footer>
    </header>
    <div class="main">
        <div class="mainBoxHeader">
            <nav class="navbar navbar-expand">
                <a class="sidebar-toggle d-flex me-2" href="#">
                    <i class="fas fa-bars fa-fw"></i>
                </a>
                <?php if(count(config('admiko_global_search'))>0 || count(config('admiko_global_search_custom'))>0): ?>
                    <div class="admikoGlobalSearch">
                        <input name="search" type="text" placeholder="<?php echo e(trans('admiko.search')); ?>" autocomplete="off">
                        <div class="admikoGlobalSearchResults"></div>
                    </div>
                <?php endif; ?>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item navbar-user d-flex flex-row">
                        <div>
                            <div class="sidebar-user-name"><?php echo e(auth()->user()->name); ?></div>
                            <div class="sidebar-user-email"><?php echo e(auth()->user()->email); ?></div>
                        </div>
                        <a class="nav-link" href="<?php echo e(route("admin.myaccount")); ?>">
                            <img src="<?php echo e(auth()->user()->image); ?>" class="img-fluid rounded-circle">
                        </a>
                    </li>
                    <li class="nav-item myaccount<?php echo e($admiko_data['sideBarActive'] === "myaccount" ? " active" : ""); ?>">
                        <a class="nav-link" href="<?php echo e(route("admin.myaccount")); ?>" title="<?php echo e(trans('admiko.myaccount')); ?>"><i class="fas fa-user fa-fw"></i></a>
                    </li>
                    <li class="nav-item logout">
                        <a class="nav-link" href="<?php echo e(route("admin.logout")); ?>" title="<?php echo e(trans('admiko.logout')); ?>"><i class="fas fa-power-off fa-fw"></i></a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="mainBoxBreadcrumb">
            <div class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route("admin.home")); ?>"><i class="fas fa-home"></i><?php echo e(trans('admiko.home')); ?></a></li>
                <?php echo $__env->yieldContent('breadcrumbs'); ?>
            </div>
        </div>
        <div class="mainBoxTitle">
            <?php echo $__env->yieldContent('pageTitle'); ?>
        </div>
        <div class="mainBoxInfo"><?php echo $__env->yieldContent('pageInfo'); ?></div>

        <div class="mainBoxBackBtn">
            <?php echo $__env->yieldContent('backBtn'); ?>
        </div>
        <div class="mainBoxContent">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="content">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.layouts.footer_custom_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer_custom_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/layouts/default.blade.php ENDPATH**/ ?>