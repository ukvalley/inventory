<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	Technical Panel

</body>
</html><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/technician_panel.blade.php ENDPATH**/ ?>