<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active"><a href="<?php echo e(route("admin.sales.index")); ?>">Sales</a></li>
    <?php if(isset($data)): ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_edit')); ?></li>
    <?php else: ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_add')); ?></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
<h1>Sales</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
<a href="<?php echo e(route("admin.sales.index")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card formPage sales_manage admikoForm">
    <legend class="action"><?php echo e(isset($data) ? trans('admiko.update') : trans('admiko.add_new')); ?></legend>
    <form method="POST" action="<?php echo e($admiko_data['formAction']); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php if(isset($data)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if($errors->any()): ?><div class="row"><div class="col-2"></div><div class="col"><div class="invalid-feedback d-block"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($error); ?><br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div></div><?php endif; ?>
            <div class="row">
                
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="date" class="col-md-2 col-form-label">Date:</label>
                        <div class="col-md-10">
                            <div class="input-group" id="dateTimePicker_date" data-target-input="nearest">
                                <input type="text" autocomplete="off" style="max-width: 170px;border-right: unset;"
                                       data-date_time_format="<?php echo e(config('admiko_config.form_date_time_format')); ?>"
                                       class="form-control datetimepicker-input dateTimePicker"
                                       data-target="#dateTimePicker_date"  id="date" data-toggle="datetimepicker"
                                       placeholder="Date" name="date" value="<?php echo e(old('date', isset($data)?$data->date : '')); ?>">
                                <div class="input-group-append input-group-text" data-target="#dateTimePicker_date" data-toggle="datetimepicker">
                                    <i class="fas fa-calendar-alt fa-fw"></i>
                                </div>
                            </div>
                            <div class="invalid-feedback <?php if($errors->has('date')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="date_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="device_id" class="col-md-2 col-form-label">Device Id:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="device_id" name="device_id"  placeholder="Device Id"  value="<?php echo e(old('device_id', isset($data)?$data->device_id : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('device_id')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="device_id_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="device_number" class="col-md-2 col-form-label">Device Number:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="device_number" name="device_number"  placeholder="Device Number"  value="<?php echo e(old('device_number', isset($data)?$data->device_number : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('device_number')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="device_number_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="allocated_to" class="col-md-2 col-form-label">Allocated To:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="allocated_to" name="allocated_to"  placeholder="Allocated To"  value="<?php echo e(old('allocated_to', isset($data)?$data->allocated_to : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('allocated_to')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="allocated_to_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="user_id" class="col-md-2 col-form-label">User Id:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="user_id" name="user_id"  placeholder="User Id"  value="<?php echo e(old('user_id', isset($data)?$data->user_id : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('user_id')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="user_id_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer form-actions" id="form-group-buttons">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary float-start me-1 mb-1 mb-sm-0 save-button"><?php echo e(trans('admiko.table_save')); ?></button>
                    <a href="<?php echo e(route("admin.sales.index")); ?>" class="btn btn-secondary float-end" role="button"><?php echo e(trans('admiko.table_cancel')); ?></a>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/sales/manage.blade.php ENDPATH**/ ?>