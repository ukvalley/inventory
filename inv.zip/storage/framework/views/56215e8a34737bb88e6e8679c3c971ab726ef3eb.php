<script>
    var noTableData = '<?php echo e(trans('admiko.noTableData')); ?>';
    var tableInfo = '<?php echo e(trans('admiko.tableInfo')); ?>';
    var dragDropTableInfo = '<?php echo e(trans('admiko.dragDropTableInfo')); ?>';
    var lengthMenu = <?php echo config("admiko_config.length_menu_table_JS"); ?>;
    var csrf_token = "<?php echo e(csrf_token()); ?>";
    var mapStartZoom = <?php echo e(config('admiko_config.map_start_zoom')); ?>;
    var mapStarLatitude = <?php echo e(config('admiko_config.map_star_latitude')); ?>;
    var mapStarLongitude = <?php echo e(config('admiko_config.map_star_longitude')); ?>;
    /*Admiko Global Search*/
    var AdmikoGlobalSearchUrl = '<?php echo e(route("admin.admiko_global_search")); ?>';
    var searchTypeMore = '<?php echo e(trans('admiko.search_type_more')); ?>';
    var searchNoResults = '<?php echo e(trans('admiko.search_no_results')); ?>';
    var searchError = '<?php echo e(trans('admiko.search_error')); ?>';
</script>
<script src="<?php echo e(asset('assets/admiko/vendors/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admiko/vendors/jquery/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/vendors/jquery-ui-1.12.1/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/vendors/datepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/vendors/datepicker/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/vendors/select2/js/select2.full.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/vendors/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/vendors/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/vendors/listjs/list.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/js/global.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/js/index_start.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/js/form_start.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/js/form_validate.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admiko/js/avatar.js')); ?>"></script>
<?php if(config('admiko_config.google_map_api_key')): ?>
    <script src="//maps.googleapis.com/maps/api/js?key=<?php echo e(config('admiko_config.google_map_api_key')); ?>&callback=startGoogleMaps" async defer></script>
<?php endif; ?>
<?php if(config('admiko_config.bing_map_api_key')): ?>
    <script>
        var bingKey = "<?php echo e(config('admiko_config.bing_map_api_key')); ?>";
    </script>
    <script type='text/javascript' src='//www.bing.com/api/maps/mapcontrol?callback=startBingMaps' async defer></script>
<?php endif; ?>
<?php echo $__env->yieldPushContent('footerCode'); ?>
<?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/layouts/footer_scripts.blade.php ENDPATH**/ ?>