<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div  class="content-wrapper">
        <div>
            <div class="panel panel-default">
                <div class="panel-heading role-list-info-header">
                  <a href="<?php echo e(url('/add_device')); ?>" class="btn btn-success">Register New Device</a>
                    <p>Device Table</p>
                    
                </div>

                <!-- /.panel-heading -->
                <div class="panel-body">




<table class="table table-striped table-dark">
  <thead>
    <tr>
      
      <th scope="col"><table class="table table-striped table-dark">
  <thead>
    <tr>
    <th scope="col">id</th>
      <th scope="col">Make</th>
      <th scope="col">ICE_ID</th>
      <th scope="col">IMEI</th>
      <th scope="col">SIM1</th>
      <th scope="col">SIM1 Type</th>
      <th scope="col">SIM2</th>
      <th scope="col">SIM2 Type</th>
      <th scope="col">Activation Date</th>
       <th scope="col">Received Date</th>
        <th scope="col">Renewal Date</th>

      <!-- <th scope="col">Edit</th>
      <th scope="col">Delete</th> -->
      
      
    </tr>
  </thead>
  <?php  $data=DB::table('device')->get();?>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->make); ?></td>
                <td><?php echo e($row->ice_id); ?></td>
                <td><?php echo e($row->imei); ?></td>
                <td><?php echo e($row->sim1); ?></td>
                <td><?php echo e($row->sim1_type); ?></td>
                <td><?php echo e($row->sim2); ?></td>
                  <td><?php echo e($row->sim2_type); ?></td>
                  <td><?php echo e($row->activation_date); ?></td>
                  <td><?php echo e($row->received_date); ?></td>
                  <td><?php echo e($row->renewal_date); ?></td>
               <a href="<?php echo e(url('/')); ?>/device_edit?id=<?php echo e($row->id); ?>" class="btn btn-primary">Edit</a>
                </td>
                <td>
                <a href="<?php echo e(url('/')); ?>/device_destroy?id=<?php echo e($row->id); ?>" class="btn btn-danger">Delete</a>
                </td>
                
            
                 
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    </div>

    <?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/device_table.blade.php ENDPATH**/ ?>