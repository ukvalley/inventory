<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active"><a href="<?php echo e(route("admin.vechicles.index")); ?>">Vechicles</a></li>
    <?php if(isset($data)): ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_edit')); ?></li>
    <?php else: ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_add')); ?></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
<h1>Vechicles</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
<a href="<?php echo e(route("admin.vechicles.index")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card formPage vechicles_manage admikoForm">
    <legend class="action"><?php echo e(isset($data) ? trans('admiko.update') : trans('admiko.add_new')); ?></legend>
    <form method="POST" action="<?php echo e($admiko_data['formAction']); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php if(isset($data)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if($errors->any()): ?><div class="row"><div class="col-2"></div><div class="col"><div class="invalid-feedback d-block"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($error); ?><br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div></div><?php endif; ?>
            <div class="row">
                
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="vechicle_number" class="col-md-2 col-form-label">Vechicle Number:*</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="vechicle_number" name="vechicle_number" required="true" placeholder="Vechicle Number"  value="<?php echo e(old('vechicle_number', isset($data)?$data->vechicle_number : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('vechicle_number')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="vechicle_number_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="customer" class="col-md-2 col-form-label">Customer:*</label>
                        <div class="col-md-10">
                            <select class="form-select" id="customer" name="customer" required="true">
                                
                                <?php $__currentLoopData = $customer_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((old('customer') ? old('customer') : $data->customer ?? '') == $id ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback <?php if($errors->has('customer')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="customer_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>

                <div class=" col-12">
                    <div class="form-group row">
                        <label for="rc_book_file" class="col-md-2 col-form-label">RC Book File:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->rc_book_file) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["rc_book_file"]['original']["folder"].$data->rc_book_file)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["rc_book_file"]['original']["folder"].$data->rc_book_file)); ?>" target="_blank"><?php echo e($data->rc_book_file); ?></a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="rc_book_file_admiko_delete" id="rc_book_file_admiko_delete" value="1">
                                <label class="form-check-label" for="rc_book_file_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="fileUpload mt-1" id="rc_book_file"  name="rc_book_file" >
                            <input type="hidden" id="rc_book_file_admiko_current" name="rc_book_file_admiko_current" value="<?php echo e($data->rc_book_file??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('rc_book_file')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_text')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('rc_book_file')): ?><?php echo e($errors->first('rc_book_file')); ?><?php endif; ?>
                            </div>
                            <small id="rc_book_file_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="vehicle_image_1" class="col-md-2 col-form-label">Vehicle Image 1:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->vehicle_image_1) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["vehicle_image_1"]['original']["folder"].$data->vehicle_image_1)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_1"]['original']["folder"].$data->vehicle_image_1)); ?>" target="_blank" class="tableImage">
                                    <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_1"]['original']["folder"].$data->vehicle_image_1)); ?>">
                                </a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="vehicle_image_1_admiko_delete" id="vehicle_image_1_admiko_delete" value="1">
                                <label class="form-check-label" for="vehicle_image_1_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="imageUpload mt-1" id="vehicle_image_1" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg"  name="vehicle_image_1"  data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>" >
                            <input type="hidden" id="vehicle_image_1_admiko_current" name="vehicle_image_1_admiko_current" value="<?php echo e($data->vehicle_image_1??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('vehicle_image_1')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('vehicle_image_1')): ?><?php echo e($errors->first('vehicle_image_1')); ?><?php endif; ?>
                            </div>
                            <small id="vehicle_image_1_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>1920px, <?php echo e(trans("admiko.height")); ?>1080px. <?php echo e(trans("admiko.image_action")); ?><?php echo e(trans("admiko.image_action_resize")); ?>.</small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="vehicle_image_2" class="col-md-2 col-form-label">Vehicle image 2:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->vehicle_image_2) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["vehicle_image_2"]['original']["folder"].$data->vehicle_image_2)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_2"]['original']["folder"].$data->vehicle_image_2)); ?>" target="_blank" class="tableImage">
                                    <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_2"]['original']["folder"].$data->vehicle_image_2)); ?>">
                                </a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="vehicle_image_2_admiko_delete" id="vehicle_image_2_admiko_delete" value="1">
                                <label class="form-check-label" for="vehicle_image_2_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="imageUpload mt-1" id="vehicle_image_2" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg"  name="vehicle_image_2"  data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>" >
                            <input type="hidden" id="vehicle_image_2_admiko_current" name="vehicle_image_2_admiko_current" value="<?php echo e($data->vehicle_image_2??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('vehicle_image_2')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('vehicle_image_2')): ?><?php echo e($errors->first('vehicle_image_2')); ?><?php endif; ?>
                            </div>
                            <small id="vehicle_image_2_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>1920px, <?php echo e(trans("admiko.height")); ?>1080px. <?php echo e(trans("admiko.image_action")); ?><?php echo e(trans("admiko.image_action_resize")); ?>.</small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="vehicle_image_3" class="col-md-2 col-form-label">Vehicle Image 3:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->vehicle_image_3) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["vehicle_image_3"]['original']["folder"].$data->vehicle_image_3)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_3"]['original']["folder"].$data->vehicle_image_3)); ?>" target="_blank" class="tableImage">
                                    <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_3"]['original']["folder"].$data->vehicle_image_3)); ?>">
                                </a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="vehicle_image_3_admiko_delete" id="vehicle_image_3_admiko_delete" value="1">
                                <label class="form-check-label" for="vehicle_image_3_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="imageUpload mt-1" id="vehicle_image_3" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg"  name="vehicle_image_3"  data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>" >
                            <input type="hidden" id="vehicle_image_3_admiko_current" name="vehicle_image_3_admiko_current" value="<?php echo e($data->vehicle_image_3??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('vehicle_image_3')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('vehicle_image_3')): ?><?php echo e($errors->first('vehicle_image_3')); ?><?php endif; ?>
                            </div>
                            <small id="vehicle_image_3_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>1920px, <?php echo e(trans("admiko.height")); ?>1080px. <?php echo e(trans("admiko.image_action")); ?><?php echo e(trans("admiko.image_action_resize")); ?>.</small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="vehicle_image_4" class="col-md-2 col-form-label">Vehicle Image 4:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->vehicle_image_4) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["vehicle_image_4"]['original']["folder"].$data->vehicle_image_4)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_4"]['original']["folder"].$data->vehicle_image_4)); ?>" target="_blank" class="tableImage">
                                    <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_4"]['original']["folder"].$data->vehicle_image_4)); ?>">
                                </a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="vehicle_image_4_admiko_delete" id="vehicle_image_4_admiko_delete" value="1">
                                <label class="form-check-label" for="vehicle_image_4_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="imageUpload mt-1" id="vehicle_image_4" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg"  name="vehicle_image_4"  data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>" >
                            <input type="hidden" id="vehicle_image_4_admiko_current" name="vehicle_image_4_admiko_current" value="<?php echo e($data->vehicle_image_4??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('vehicle_image_4')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('vehicle_image_4')): ?><?php echo e($errors->first('vehicle_image_4')); ?><?php endif; ?>
                            </div>
                            <small id="vehicle_image_4_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>1920px, <?php echo e(trans("admiko.height")); ?>1080px. <?php echo e(trans("admiko.image_action")); ?><?php echo e(trans("admiko.image_action_resize")); ?>.</small>
                        </div>
                    </div>
                </div>
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="vehicle_image_5" class="col-md-2 col-form-label">Vehicle Image 5:</label>
                        <div class="col-md-10">
                            <?php if(isset($data->vehicle_image_5) && Storage::disk(config("admiko_config.filesystem"))->exists($admiko_data['fileInfo']["vehicle_image_5"]['original']["folder"].$data->vehicle_image_5)): ?>
                            <a href="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_5"]['original']["folder"].$data->vehicle_image_5)); ?>" target="_blank" class="tableImage">
                                    <img src="<?php echo e(Storage::disk(config("admiko_config.filesystem"))->url($admiko_data['fileInfo']["vehicle_image_5"]['original']["folder"].$data->vehicle_image_5)); ?>">
                                </a><br>
                                <div class="form-check form-checkbox">
                                <input class="form-check-input" type="checkbox" name="vehicle_image_5_admiko_delete" id="vehicle_image_5_admiko_delete" value="1">
                                <label class="form-check-label" for="vehicle_image_5_admiko_delete"> <?php echo e(trans('admiko.remove_file')); ?></label>
                            </div>
                            <?php endif; ?>
                            <input type="file" class="imageUpload mt-1" id="vehicle_image_5" accept=".jpg,.png,.jpeg" data-type=".jpg,.png,.jpeg"  name="vehicle_image_5"  data-selected="<?php echo e(trans('admiko.selected_image_preview')); ?>" >
                            <input type="hidden" id="vehicle_image_5_admiko_current" name="vehicle_image_5_admiko_current" value="<?php echo e($data->vehicle_image_5??''); ?>">
                            <div class="invalid-feedback <?php if($errors->has('vehicle_image_5')): ?> d-block <?php endif; ?>" data-required="<?php echo e(trans('admiko.required_image')); ?>" data-size="<?php echo e(trans('admiko.required_size')); ?>" data-type="<?php echo e(trans('admiko.required_type')); ?>">
                                <?php if($errors->has('vehicle_image_5')): ?><?php echo e($errors->first('vehicle_image_5')); ?><?php endif; ?>
                            </div>
                            <small id="vehicle_image_5_help" class="text-muted"><?php echo e(trans("admiko.file_extension_limit")); ?>.jpg,.png,.jpeg. <?php echo e(trans("admiko.recommended")); ?><?php echo e(trans("admiko.width")); ?>1920px, <?php echo e(trans("admiko.height")); ?>1080px. <?php echo e(trans("admiko.image_action")); ?><?php echo e(trans("admiko.image_action_resize")); ?>.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer form-actions" id="form-group-buttons">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary float-start me-1 mb-1 mb-sm-0 save-button"><?php echo e(trans('admiko.table_save')); ?></button>
                    <a href="<?php echo e(route("admin.vechicles.index")); ?>" class="btn btn-secondary float-end" role="button"><?php echo e(trans('admiko.table_cancel')); ?></a>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/vechicles/manage.blade.php ENDPATH**/ ?>