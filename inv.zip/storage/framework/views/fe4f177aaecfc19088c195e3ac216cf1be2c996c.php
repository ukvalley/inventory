<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	Office Panel

</body>
</html><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/office_panel.blade.php ENDPATH**/ ?>