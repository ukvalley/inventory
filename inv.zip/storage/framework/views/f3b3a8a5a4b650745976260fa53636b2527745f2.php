

<?php if(Gate::any(['customer_allow', 'customer_edit'])): ?>
<li class="nav-item<?php echo e($admiko_data['sideBarActive'] === "customer" ? " active" : ""); ?>"><a class="nav-link" href="<?php echo e(route('admin.customer.index')); ?>"><i class="fas fa-file-alt fa-fw"></i>Customer</a></li>
<?php endif; ?>
<?php if(Gate::any(['vechicles_allow', 'vechicles_edit'])): ?>
<li class="nav-item<?php echo e($admiko_data['sideBarActive'] === "vechicles" ? " active" : ""); ?>"><a class="nav-link" href="<?php echo e(route('admin.vechicles.index')); ?>"><i class="fas fa-file-alt fa-fw"></i>Vechicles</a></li>
<?php endif; ?>
<?php if(Gate::any(['users_allow', 'users_edit'])): ?>
<li class="nav-item<?php echo e($admiko_data['sideBarActive'] === "users" ? " active" : ""); ?>"><a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>"><i class="fas fa-file-alt fa-fw"></i>Users</a></li>
<?php endif; ?>
<?php if(Gate::any(['device_allow', 'device_edit'])): ?>
<li class="nav-item<?php echo e($admiko_data['sideBarActive'] === "device" ? " active" : ""); ?>"><a class="nav-link" href="<?php echo e(route('admin.device.index')); ?>"><i class="fas fa-file-alt fa-fw"></i>Device</a></li>
<?php endif; ?>
<?php if(Gate::any(['sim_types_allow', 'sim_types_edit'])): ?>
<li class="nav-item<?php echo e($admiko_data['sideBarActive'] === "sim_types" ? " active" : ""); ?>"><a class="nav-link" href="<?php echo e(route('admin.sim_types.index')); ?>"><i class="fas fa-file-alt fa-fw"></i>Sim Types</a></li>
<?php endif; ?>
<?php if(Gate::any(['purchase_allow', 'purchase_edit'])): ?>
<li class="nav-item<?php echo e($admiko_data['sideBarActive'] === "purchase" ? " active" : ""); ?>"><a class="nav-link" href="<?php echo e(route('admin.purchase.index')); ?>"><i class="fas fa-file-alt fa-fw"></i>Purchase</a></li>
<?php endif; ?>
<?php if(Gate::any(['sales_allow', 'sales_edit'])): ?>
<li class="nav-item<?php echo e($admiko_data['sideBarActive'] === "sales" ? " active" : ""); ?>"><a class="nav-link" href="<?php echo e(route('admin.sales.index')); ?>"><i class="fas fa-file-alt fa-fw"></i>Sales</a></li>
<?php endif; ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/admiko_sidebar.blade.php ENDPATH**/ ?>