<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active"><a href="<?php echo e(route("admin.sim_types.index")); ?>">Sim Types</a></li>
    <?php if(isset($data)): ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_edit')); ?></li>
    <?php else: ?>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(trans('admiko.page_breadcrumbs_add')); ?></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
<h1>Sim Types</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
<a href="<?php echo e(route("admin.sim_types.index")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card formPage sim_types_manage admikoForm">
    <legend class="action"><?php echo e(isset($data) ? trans('admiko.update') : trans('admiko.add_new')); ?></legend>
    <form method="POST" action="<?php echo e($admiko_data['formAction']); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php if(isset($data)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if($errors->any()): ?><div class="row"><div class="col-2"></div><div class="col"><div class="invalid-feedback d-block"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($error); ?><br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div></div><?php endif; ?>
            <div class="row">
                
                <div class=" col-12">
                    <div class="form-group row">
                        <label for="name" class="col-md-2 col-form-label">Name:</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" id="name" name="name"  placeholder="Name"  value="<?php echo e(old('name', isset($data)?$data->name : '')); ?>">
                            <div class="invalid-feedback <?php if($errors->has('name')): ?> d-block <?php endif; ?>"><?php echo e(trans('admiko.required_text')); ?></div>
                            <small id="name_help" class="text-muted"></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer form-actions" id="form-group-buttons">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary float-start me-1 mb-1 mb-sm-0 save-button"><?php echo e(trans('admiko.table_save')); ?></button>
                    <a href="<?php echo e(route("admin.sim_types.index")); ?>" class="btn btn-secondary float-end" role="button"><?php echo e(trans('admiko.table_cancel')); ?></a>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/sim_types/manage.blade.php ENDPATH**/ ?>