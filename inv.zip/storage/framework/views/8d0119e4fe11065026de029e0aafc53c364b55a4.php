<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 <!-- Main content -->
 <div class="content-wrapper">
 <section class="content">
               <div class="row">
                  <!-- Form controls -->
                  <div class="col-sm-12">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="btn-group" id="buttonlist"> 
                              <a class="btn btn-add " href="clist.html"> 
                              <i class="fa fa-list"></i>  Vehicle Registration </a>  
                           </div>
                        </div>
                        <div class="panel-body">
                           <form class="col-sm-6" action="<?php echo e(url('/')); ?>/register_vehicle-post" method="post"  enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                 
                                
                           <div class="form-group">
                                 <label>Vehicle Number</label>
                                 <input type="text" class="form-control" name="vechicle_number" placeholder=" Enter Vehicle Number" required>
                              </div>
                              <div class="form-group">
                                 <label>Customer</label>
                                  
                                 <select class="form-control" name="customer" >
                                   <?php $__currentLoopData = $allcustomer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>{
                                   
                                    <option value="customer" ><?php echo e($value->name); ?></option>}
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                                
                              </div>
                                    
                              <div class="form-group">
                                 <label>RC Book File</label>
                                 <input type="file" name="rc_book_file" id="rc_book_file">
                                 <input type="hidden" name="rc_book_file" id="rc_book_file">
                              </div>
                              
                              <div class="form-group">
                                 <label>Vehicle Image 1</label>
                                 <input type="file" name="vehicle_image_1"  id="vehicle_image_1">
                                 <input type="hidden" name="vehicle_image_1" id="vehicle_image_1">
                              </div>
                              <div class="form-group">
                                 <label>Vehicle Image 2</label>
                                 <input type="file" name="vehicle_image_2">
                                 <input type="hidden" name="vehicle_image_2">
                              </div>
                              <div class="form-group">
                                 <label>Vehicle Image 3</label>
                                 <input type="file" name="vehicle_image_3">
                                 <input type="hidden" name="vehicle_image_3">
                              </div>
                              <div class="form-group">
                                 <label>Vehicle Image 4</label>
                                 <input type="file" name="vehicle_image_4">
                                 <input type="hidden" name="vehicle_image_4">
                              </div>
                              <div class="form-group">
                                 <label>Vehicle Image 5</label>
                                 <input type="file" name="vehicle_image_5">
                                 <input type="hidden" name="vehicle_image_5">
                              </div>
                              <div class="reset-button">
                                 <a href="#" class="btn btn-warning">Reset</a>
                                
                                 <input class="btn btn-success" type="submit" value="Submit" />
                              </div>
                              
                           
                           
                             
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-- /.content -->
            </div>

<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/register_vehicle.blade.php ENDPATH**/ ?>