<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active"><?php echo e(trans('admiko.admins_page_import_title')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
    <h1><?php echo e(trans('admiko.admins_page_import_title')); ?></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?>
    <a href="<?php echo e(route("admin.home")); ?>"><i class="fas fa-angle-left"></i> <?php echo e(trans('admiko.page_back_btn')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors): ?>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col"><div class="invalid-feedback d-block"><?php echo $errors; ?></div></div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <?php if($admikoUpdateInfo): ?>
            <div class="card">
                <div class="card-body">
                    <h4>Admiko update:</h4>
                    <?php echo $admikoUpdateInfo; ?>

                    <form method="post" action="<?php echo e(route("admin.admiko_page_import.import")); ?>">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            <p class="text-muted pb-2"><?php echo e(trans('admiko.admins_admiko_update_backup_info')); ?> <?php echo e(base_path().'/'.config("admiko_config.backup_location")); ?></p>
                        </div>
                        <input type="hidden" name="admikoUpdate" value="1">
                        <div class="btn btn-primary spinnerBox" style="display: none"><div class="h-100 d-flex align-items-center justify-content-around"><div class="spinner-border spinner-border-sm" role="status"></div></div></div>
                        <button type="submit" class="btn btn-primary importButtonAdmikoUpdate"><i class="fas fa-download fa-fw"></i> <?php echo e(trans('admiko.admins_admiko_update')); ?></button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <div class="tableBox">
                    <div class="row">
                        <div class="col-auto mb-2 lengthTable">Admiko early access: v.<?php echo e(config("admiko_version.version")); ?></div>
                        <div class="col mb-2 searchTable">
                            <div class="input-group ms-auto">
                                <input type="text" name="admiko_search" class="form-control" placeholder="Search" value="">
                            </div>
                        </div>
                    </div>
                    <div class="tableLayout">
                        <table class="table" data-dom="tr" data-page-length='-1'>
                            <thead>
                            <tr data-sort-method='thead'>
                                <th scope="col" class="w-5 no-sort importSelectAll" data-orderable="false"><i class="fas fa-check-double"></i> <?php echo e(trans('admiko.admins_page_import')); ?></th>
                                <th scope="col" class=""><?php echo e(trans('admiko.admins_page_name')); ?></th>
                                <th scope="col" class=""><?php echo e(trans('admiko.admins_soft_delete')); ?></th>
                                <th scope="col" class="w-5 no-sort" data-orderable="false"><?php echo e(trans('admiko.admins_page_import')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($tableData): ?>
                                <?php $__currentLoopData = $tableData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="w-5 no-sort">
                                            <input type="checkbox" value="<?php echo e($data->id); ?>" class="form-check-input importSelectMe" id="page_<?php echo e($data->id); ?>">
                                        </td>
                                        <td class=" nowrap"><label for="page_<?php echo e($data->id); ?>"><?php echo e($data->title); ?></label></td>
                                        <td class=" nowrap"><?php echo e($data->soft_delete?'Yes':'No'); ?></td>
                                        <td class="w-5 no-sort">
                                            <form method="post" action="<?php echo e(route("admin.admiko_page_import.import")); ?>">
                                                <?php echo method_field('POST'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($data->id); ?>" name="page_id[]">
                                                <div class="btn btn-primary spinnerBox" style="display: none"><div class="h-100 d-flex align-items-center justify-content-around"><div class="spinner-border spinner-border-sm" role="status"></div></div></div>
                                                <button type="submit" class="btn btn-primary importButton"><i class="fas fa-download fa-fw" style="color: white"></i> <?php echo e(trans('admiko.admins_page_import')); ?></button>
                                                <div class="singleImportFinished" style="display: none"><i class="fas fa-check"></i> <?php echo e(trans('admiko.admins_page_import_single_finished')); ?></div>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <form method="post" action="<?php echo e(route("admin.admiko_page_import.import")); ?>">
                            <?php echo method_field('POST'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="col-12 col-sm order-3 order-sm-0 pt-3">
                                <div class="row multiImportForm pt-2" style="display: none">
                                    <div class="col-12">
                                        <div class="dataImport"></div>
                                        <div class="btn btn-primary spinnerBox" style="display: none"><div class="h-100 d-flex align-items-center justify-content-around"><div class="spinner-border spinner-border-sm" role="status"></div></div></div>
                                        <button type="submit" class="btn btn-primary importAllButton" style="width: 100px"><i class="fas fa-download fa-fw"></i> <?php echo e(trans('admiko.admins_page_import')); ?></button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="importFinished" style="display: none">
                                    <div class="alert alert-success mt-3" role="alert"><i class="fas fa-check"></i> <?php echo e(trans('admiko.admins_page_import_finished')); ?></div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="progress" style="display: none">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-12">
                        <p class="text-muted py-2"><?php echo e(trans('admiko.admins_admiko_update_backup_info')); ?> <?php echo e(base_path().'/'.config("admiko_config.backup_location")); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Error -->
        <div class="modal fade" id="errorInfo" tabindex="-1" role="dialog" aria-labelledby="errorInfo" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo e(trans('admiko.error_page_import_title')); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body"><?php echo e(trans('admiko.error_page_import_message')); ?></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(trans('admiko.error_page_import_close_btn')); ?></button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerCode'); ?>
    <script>
        $('.tableLayout').on('click', '.importSelectAll', function (event) {
            event.preventDefault();
            var checkBoxes = $(".importSelectMe");
            checkBoxes.prop("checked", !checkBoxes.prop("checked"));
            showImportButton();
        });
        $('.tableLayout').on('click', '.importSelectMe', function (event) {
            showImportButton();
        });
        $('.importButtonAdmikoUpdate').on('click', function (event) {
            var form = $(this).closest('form');
            form.find('.importButtonAdmikoUpdate').hide();
            form.find('.spinnerBox').show();
        })
        $('.importButton').on('click', function (event) {
            event.preventDefault();
            var form = $(this).closest('form');
            var data = form.serialize();
            form.find('.importButton').hide();
            form.find('.spinnerBox').show();
            form.find('.singleImportFinished').hide();
            $.ajax({
                url: form.attr('action'),
                type: 'post',
                data: data,
                dataType: 'json',
                success: function (results) {
                    if (results.status == "done") {
                        form.find('.importButton').show();
                        form.find('.spinnerBox').hide();
                        form.find('.singleImportFinished').show();
                        importGlobalFiles(form);
                    } else {
                        $('#errorInfo').modal('show');
                    }
                },
                error: function () {
                    $('#errorInfo').modal('show');
                }
            });
        });

        var totalPages = 0;
        var totalPagesFinished = 0;
        var progress = 0;
        var backup_folder = '';

        $('.multiImportForm').on('click', '.importAllButton',function (event) {
            event.preventDefault();
            backup_folder = '';
            var form = $(this).closest('form');
            form.find('.multiImportForm').hide();
            form.find('.progress').show();
            form.find('.progress-bar').css('width', '0%').attr('aria-valuenow', 0);
            form.find('.importFinished').slideUp();
            totalPages = form.find('.dataImport input').length + 1;
            totalPagesFinished = 0;
            progress = 0;
            startImport(form.find('.dataImport input').serializeArray(),0,form);
        });
        function startImport(data,i,form) {
            totalPagesFinished++;
            progress = (totalPagesFinished/totalPages)*100;
            form.find('.progress-bar').css('width', progress+'%').attr('aria-valuenow', progress);

            $.ajax({
                url: form.attr('action'),
                type: 'post',
                data: {'page_id[]': data[i]['value'], '_token': form.find("input[name=_token]").val(), 'backup_folder': backup_folder},
                dataType: 'json',
                success: function (results) {
                    if (results.status == "done") {
                        backup_folder = results.backup_folder;
                        i++;
                        if(data.length > i){
                            startImport(data,i,form)
                        } else {
                            importGlobalFiles(form)
                        }
                    } else {
                        $('#errorInfo').modal('show');
                    }
                },
                error: function () {
                    $('#errorInfo').modal('show');
                }
            });
        }
        function importGlobalFiles(form) {
            totalPagesFinished++;
            progress = (totalPagesFinished/totalPages)*100;
            form.find('.progress-bar').css('width', progress+'%').attr('aria-valuenow', progress);
            $.ajax({
                url: form.attr('action'),
                type: 'post',
                data: {'importGlobal': 1, '_token': form.find("input[name=_token]").val(), 'backup_folder': backup_folder},
                dataType: 'json',
                success: function (results) {
                    if (results.status == "done") {
                        form.find('.progress').hide();
                        form.find('.multiImportForm').show();
                        form.find('.importFinished').slideDown();
                    } else {
                        $('#errorInfo').modal('show');
                    }
                },
                error: function () {
                    $('#errorInfo').modal('show');
                }
            });
        }

        function showImportButton() {
            if ($(".importSelectMe:checked").length > 0) {
                $('.dataImport').html('');
                $(".importSelectMe:checked").each(function (i) {
                    importId = $(this).val();
                    $('<input>').attr({
                        type: 'hidden',
                        value: importId,
                        name: 'page_id[]'
                    }).appendTo('.dataImport');
                })
                $(".multiImportForm").show();
            } else {
                $(".multiImportForm").hide();
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/admins/admiko_page_import/index.blade.php ENDPATH**/ ?>