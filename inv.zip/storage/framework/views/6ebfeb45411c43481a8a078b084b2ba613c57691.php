<?php $__env->startSection('breadcrumbs'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle'); ?>
    <h1><?php echo e(trans('admiko.home')); ?></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageInfo'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('backBtn'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.default", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Ncmart.in/public_html/inventory/resources/views/admin/home/index.blade.php ENDPATH**/ ?>