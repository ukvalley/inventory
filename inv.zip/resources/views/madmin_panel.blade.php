@include('common.header')

<h1>MAdmin Panel
</h1>



@include('common.footer')



